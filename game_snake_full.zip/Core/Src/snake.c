#include "snake.h"
#include "ssd1306.h"
#include <stdlib.h>

#define WIDTH 128
#define HEIGHT 64
#define TILE 8
#define MAX_SNAKE (16*8)

typedef struct{ int x,y; } pos_t;
static pos_t snake[MAX_SNAKE];
static int snake_len;
static pos_t food;
static int dir; // 0 up,1 right,2 down,3 left
static uint32_t last_ms;

static void place_food(void){
    while(1){
        int fx = (rand() % (WIDTH / TILE)) * TILE;
        int fy = (rand() % (HEIGHT / TILE)) * TILE;
        int ok=1;
        for(int i=0;i<snake_len;i++) if(snake[i].x==fx && snake[i].y==fy){ ok=0; break; }
        if(ok){ food.x=fx; food.y=fy; return; }
    }
}

void snake_init(void){
    snake_len = 3;
    snake[0].x = TILE*4; snake[0].y = TILE*3;
    snake[1].x = snake[0].x - TILE; snake[1].y = snake[0].y;
    snake[2].x = snake[1].x - TILE; snake[2].y = snake[1].y;
    dir = 1; last_ms = hw_millis();
    place_food();
}

void snake_update(void){
    if(hw_button_up() && dir != 2) dir = 0;
    else if(hw_button_right() && dir != 3) dir = 1;
    else if(hw_button_down() && dir != 0) dir = 2;
    else if(hw_button_left() && dir != 1) dir = 3;

    uint32_t now = hw_millis();
    if(now - last_ms < 200) return;
    last_ms = now;

    pos_t head = snake[0];
    if(dir==0) head.y -= TILE;
    else if(dir==2) head.y += TILE;
    else if(dir==1) head.x += TILE;
    else head.x -= TILE;

    if(head.x < 0 || head.x >= WIDTH || head.y < 0 || head.y >= HEIGHT){
        snake_init(); return;
    }
    for(int i=0;i<snake_len;i++) if(snake[i].x==head.x && snake[i].y==head.y){ snake_init(); return; }

    for(int i=snake_len;i>0;i--) snake[i]=snake[i-1];
    snake[0]=head;

    if(head.x==food.x && head.y==food.y){
        snake_len++; if(snake_len>MAX_SNAKE) snake_len=MAX_SNAKE; place_food();
    }
}

void snake_draw(void){
    SSD1306_Clear();
    // draw snake
    for(int i=0;i<snake_len;i++){
        SSD1306_FillRect(snake[i].x, snake[i].y, TILE-1, TILE-1);
    }
    // draw food
    SSD1306_FillRect(food.x, food.y, TILE-1, TILE-1);
    // draw score - small
    SSD1306_DrawText(2, 2, "S");
    SSD1306_UpdateScreen();
}
