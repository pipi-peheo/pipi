#include "main.h"
#include "ssd1306.h"
#include "snake.h"
#include "stm32l1xx_hal.h"

extern I2C_HandleTypeDef hi2c1;
void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_I2C1_Init(void);

int main(void){
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();

    SSD1306_Init();
    snake_init();

    while(1){
        snake_update();
        snake_draw();
        HAL_Delay(10);
    }
    return 0;
}
