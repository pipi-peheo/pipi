#include "ssd1306.h"
#include "main.h"
#include <string.h>
#include <stdlib.h>

extern I2C_HandleTypeDef hi2c1;

/* SSD1306 I2C address: change to 0x3D<<1 if needed */
#define SSD1306_ADDR (0x3C << 1)

static uint8_t fb[128 * 64 / 8];

static void ssd1306_write_cmd(uint8_t cmd){
    uint8_t buf[2] = {0x00, cmd};
    HAL_I2C_Master_Transmit(&hi2c1, SSD1306_ADDR, buf, 2, HAL_MAX_DELAY);
}
static void ssd1306_write_data(const uint8_t *data, size_t len){
    uint8_t control = 0x40;
    HAL_I2C_Mem_Write(&hi2c1, SSD1306_ADDR, control, I2C_MEMADD_SIZE_8BIT, (uint8_t*)data, len, HAL_MAX_DELAY);
}

void SSD1306_Init(void){
    HAL_Delay(50);
    ssd1306_write_cmd(0xAE);
    ssd1306_write_cmd(0x20); ssd1306_write_cmd(0x00);
    ssd1306_write_cmd(0xB0);
    ssd1306_write_cmd(0xC8);
    ssd1306_write_cmd(0x00);
    ssd1306_write_cmd(0x10);
    ssd1306_write_cmd(0x40);
    ssd1306_write_cmd(0x81); ssd1306_write_cmd(0x7F);
    ssd1306_write_cmd(0xA1);
    ssd1306_write_cmd(0xA6);
    ssd1306_write_cmd(0xA8); ssd1306_write_cmd(0x3F);
    ssd1306_write_cmd(0xD3); ssd1306_write_cmd(0x00);
    ssd1306_write_cmd(0xD5); ssd1306_write_cmd(0x80);
    ssd1306_write_cmd(0xD9); ssd1306_write_cmd(0xF1);
    ssd1306_write_cmd(0xDA); ssd1306_write_cmd(0x12);
    ssd1306_write_cmd(0xDB); ssd1306_write_cmd(0x40);
    ssd1306_write_cmd(0x8D); ssd1306_write_cmd(0x14);
    ssd1306_write_cmd(0xAF);
    memset(fb,0,sizeof(fb));
    SSD1306_UpdateScreen();
}

void SSD1306_Clear(void){
    memset(fb,0,sizeof(fb));
}

void SSD1306_UpdateScreen(void){
    for(uint8_t page=0; page<8; page++){
        ssd1306_write_cmd(0xB0 + page);
        ssd1306_write_cmd(0x00);
        ssd1306_write_cmd(0x10);
        ssd1306_write_data(&fb[128*page], 128);
    }
}

void SSD1306_DrawPixel(uint8_t x, uint8_t y, uint8_t color){
    if(x>=128 || y>=64) return;
    uint32_t idx = (y>>3)*128 + x;
    if(color) fb[idx] |= (1 << (y & 7));
    else fb[idx] &= ~(1 << (y & 7));
}

void SSD1306_FillRect(int x, int y, int w, int h){
    for(int yy=y; yy<y+h; yy++){
        for(int xx=x; xx<x+w; xx++){
            SSD1306_DrawPixel(xx, yy, 1);
        }
    }
}

static void draw_char3x5(int x, int y, char c){
    static const uint8_t font3x5[][3] = {
      {0x0E,0x11,0x0E},{0x00,0x12,0x1F},{0x12,0x19,0x16},{0x11,0x15,0x0A},
      {0x06,0x05,0x1F},{0x17,0x15,0x09},{0x0E,0x15,0x09},{0x01,0x19,0x07},
      {0x0A,0x15,0x0A},{0x02,0x15,0x0E},{0x1F,0x05,0x1F},{0x00,0x1F,0x00}
    };
    if(c>='0' && c<='9'){
        const uint8_t *g = font3x5[c-'0'];
        for(int col=0; col<3; col++){
            uint8_t cb = g[col];
            for(int row=0; row<5; row++){
                if(cb & (1<<row)) SSD1306_DrawPixel(x+col, y+row, 1);
            }
        }
    } else {
        // basic ASCII fallback - draw space
    }
}

void SSD1306_DrawText(int x, int y, const char *s){
    while(*s){
        draw_char3x5(x,y,*s++);
        x += 4;
    }
}

/* hw helpers (buttons/time) - user should map pins in main project */
#include "stm32l1xx_hal.h"
extern TIM_HandleTypeDef htim6;
uint32_t hw_millis(void){
    return HAL_GetTick();
}
void hw_delay_ms(uint32_t ms){ HAL_Delay(ms); }

int hw_button_left(void){ return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET; }
int hw_button_right(void){ return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) == GPIO_PIN_RESET; }
int hw_button_up(void){ return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2) == GPIO_PIN_RESET; }
int hw_button_down(void){ return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3) == GPIO_PIN_RESET; }
