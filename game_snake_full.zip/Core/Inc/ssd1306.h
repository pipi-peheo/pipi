#ifndef __SSD1306_H__
#define __SSD1306_H__

#include <stdint.h>
#include <stddef.h>

void SSD1306_Init(void);
void SSD1306_Clear(void);
void SSD1306_UpdateScreen(void);
void SSD1306_DrawPixel(uint8_t x, uint8_t y, uint8_t color);
void SSD1306_FillRect(int x, int y, int w, int h);
void SSD1306_DrawText(int x, int y, const char *s);

uint32_t hw_millis(void);
void hw_delay_ms(uint32_t ms);
int hw_button_left(void);
int hw_button_right(void);
int hw_button_up(void);
int hw_button_down(void);

#endif
