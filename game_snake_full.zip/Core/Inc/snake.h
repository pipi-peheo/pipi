#ifndef __SNAKE_H__
#define __SNAKE_H__
void snake_init(void);
void snake_update(void);
void snake_draw(void);
#endif
